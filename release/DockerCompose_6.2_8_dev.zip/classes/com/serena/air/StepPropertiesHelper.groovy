package com.serena.air

import org.apache.log4j.Level
import org.apache.log4j.LogManager
import org.apache.log4j.Logger


class StepPropertiesHelper {
    private static final Logger logger = Logger.getLogger(StepPropertiesHelper.class)

    private Properties props
    private boolean trim = false
    
    public StepPropertiesHelper(Map aprops){
        props = new Properties()
        props.putAll(aprops)
    }
    public StepPropertiesHelper(Map aprops, boolean trim){
        props = new Properties()
        props.putAll(aprops)
        this.trim = trim
    }

    public void trimStringValues(boolean trim) {
        this.trim = trim
    }

    //-------------------------------------------------------------------------
    // Main prop access methods

    //------------------
    //String methods
    public String notNull(String paramName) {
        String res = props.getProperty(paramName);
        if (res == null || res.isEmpty()) {
            throw new StepFailedException("Parameter " + paramName + " is missing!")
        } else if(trim){
            res = res.trim()
            logger.debug("Reading parameter '$paramName': '$res' (value is trimmed)")
            return res
        }
        logger.debug("Reading parameter '$paramName': '$res'")
        return res;
    }
    public String optional(String paramName) {
        return optional(paramName, "");
    }
    public String optional(String paramName, String defValue) {
        String res = props.getProperty(paramName);
        if(res == null || res.isEmpty()){
            logger.debug("Reading parameter '$paramName': '$defValue' (using default value)")
            return defValue
        } else if(trim){
            logger.debug("Reading parameter '$paramName': '$res' (value is trimmed)")
            return res.trim()
        }
        logger.debug("Reading parameter '$paramName': '$res'")
        return res
    }

    //------------------
    // INT methods
    public int notNullInt(String paramName) {
        try{
            String res = props.getProperty(paramName)
            if (res == null || res.isEmpty()) {
                throw new StepFailedException("Parameter " + paramName + " is missing!")
            }
            int intRes = Integer.parseInt(res.trim());
            logger.debug("Reading parameter '$paramName' (int): '$res' => '$intRes'")
            return intRes
        } catch (NumberFormatException e){
            throw new StepFailedException("Parameter $paramName is not a valid number!", e)
        }
    }
    public int optionalInt(String paramName, int defValue) {
        try{
            String res = props.getProperty(paramName)
            if (res == null || res.isEmpty()) {
                logger.debug("Reading parameter '$paramName' (int): '$defValue' (using default value)")
                return defValue;
            }
            int intRes = Integer.parseInt(res.trim());
            logger.debug("Reading parameter '$paramName' (int): '$res' => '$intRes'")
            return intRes
        } catch (NumberFormatException e){
            throw new StepFailedException("Parameter $paramName is not a valid number!", e)
        }
    }

    //------------------
    // Boolean methods
    public boolean notNullBoolean(String paramName) {
        String res = props.getProperty(paramName);
        if (res == null || res.isEmpty()) {
            throw new StepFailedException("Parameter " + paramName + " is missing!")
        }
        boolean boolRes = Boolean.parseBoolean(res.trim());
        logger.debug("Reading parameter '$paramName' (boolean): '$res' => '$boolRes'")
        return boolRes
    }
    public boolean optionalBoolean(String paramName, boolean defValue) {
        String res = props.getProperty(paramName);
        if (res == null || res.isEmpty()) {
            logger.debug("Reading parameter '$paramName' (boolean): '$defValue' (using default value)")
            return defValue
        }
        boolean boolRes = Boolean.parseBoolean(res.trim());
        logger.debug("Reading parameter '$paramName' (boolean): '$res' => '$boolRes'")
        return boolRes
    }

    //-------------------------------------------------------------------------

    public def getAt(key){
        props[key]    
    }

    public def putAt(key, value){
        props[key] = value
    } 

    public static List<String> splitTextArea(String text){
        return StepPropertiesHelper.splitTextAreaIntoLines(text).collect {StepPropertiesHelper.splitKeyValueLine(it)}
    }

    public static List<String> splitTextAreaIntoLines(String text){
        return splitTextAreaIntoLines(text, '\n');
    }

    public static List<String> splitTextAreaIntoLines(String text, String separator){
        List<String> lines = text.split(separator)
                .collect{it.trim()}
                .findAll{!it.isEmpty() && !it.startsWith('#')}
        return lines
    }

    public static List<String> splitKeyValueLine(String text){
        return text.split('=').collect{it.trim()}
    }

    public boolean setDebugLoggingMode(){
        return setDebugLoggingMode('debug')
    }
    public boolean setDebugLoggingMode(String debugCheckBoxName){
        if(optionalBoolean(debugCheckBoxName, false)){
            LogManager.getLogger('com.serena').setLevel(Level.DEBUG);
            logger.info 'Setting log level to DEBUG'
            return true
        } else {
            logger.info 'Logging level is: ' + LogManager.getLogger('com.serena').getLevel()
            return false
        }
    }
}
