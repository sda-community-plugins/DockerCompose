package com.serena.air.http

import com.urbancode.commons.util.httpclient.ApacheHttpClientFactory
import org.apache.http.impl.client.CloseableHttpClient;

class SDAHttpClientHelper {

    public static CloseableHttpClient getHttpClient(String username, String password) {
        String proxyHost = System.env['PROXY_HOST'] ? System.env['PROXY_HOST'] : null
        Integer proxyPort = System.env['PROXY_PORT'] ? Integer.valueOf((String) System.env['PROXY_PORT']) : null

        String sslEnabledProtocolsString = System.getenv()['SSL_ENABLED_PROTOCOLS']
        ArrayList<String> sslEnabledProtocolsList = null;
        if (null != sslEnabledProtocolsString) {
            sslEnabledProtocolsList = Arrays.asList(sslEnabledProtocolsString.split(","));
        }

        String agentKeyStorePath = System.env['AGENT_KEYSTORE_PATH'] ? System.env['AGENT_KEYSTORE_PATH'] : null
        String agentKeyStorePwd = System.env['AGENT_KEYSTORE_PWD'] ? System.env['AGENT_KEYSTORE_PWD'] : null
        String agentKeyStoreKeyPwd = System.env['AGENT_KEYSTORE_KEY_PWD'] ? System.env['AGENT_KEYSTORE_KEY_PWD'] : null

        ApacheHttpClientFactory factory = new ApacheHttpClientFactory(proxyHost, proxyPort);

        factory.setKeyStoreFilePath(agentKeyStorePath);
        factory.setKeyStorePassword(agentKeyStorePwd);
        factory.setKeyPassword(agentKeyStoreKeyPwd);

        factory.setAuthUsername(username);
        factory.setAuthPassword(password);

        factory.setSupportedSSLProtocols(sslEnabledProtocolsList);
        factory.setFollowRedirects(false);
        return factory.createHttpClient();
    }

    public static CloseableHttpClient getHttpClient() {
        return getHttpClient(null, null);
    }

}
