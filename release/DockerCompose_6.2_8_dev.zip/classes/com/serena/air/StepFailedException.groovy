package com.serena.air

class StepFailedException extends Exception {
    StepFailedException() {
    }

    StepFailedException(String var1) {
        super(var1)
    }

    StepFailedException(String var1, Throwable var2) {
        super(var1, var2)
    }

    StepFailedException(Throwable var1) {
        super(var1)
    }
}
